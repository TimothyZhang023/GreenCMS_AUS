<?php

//数据库类型
define("GreenCMS_DB_TYPE", 'mysql');

//数据库地址
define("GreenCMS_DB_HOST", '~dbhost~');

//数据库名称
define("GreenCMS_DB_NAME", '~dbname~');

//用户名
define("GreenCMS_DB_USR", '~dbuser~');

//密码
define("GreenCMS_DB_PWD", '~dbpwd~');

//端口
define("GreenCMS_DB_PORT", '~dbport~');

//前缀,生产环境需要自形添加 如 green_
define("GreenCMS_DB_PREFIX", '~dbprefix~');


