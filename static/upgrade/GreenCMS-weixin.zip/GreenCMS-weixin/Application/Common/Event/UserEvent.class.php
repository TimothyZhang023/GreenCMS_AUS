<?php
/**
 * Created by Green Studio.
 * File: UserEvent.class.php
 * User: TianShuo
 * Date: 14-2-17
 * Time: 上午11:49
 */

namespace Common\Event;


class UserEvent {

}