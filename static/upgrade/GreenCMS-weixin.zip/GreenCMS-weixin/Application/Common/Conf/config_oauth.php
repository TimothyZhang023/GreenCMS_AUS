<?php

// 系统别名定义文件
return array(

    'THINK_SDK_Douban' => array(
        'APP_KEY'    => '', //应用注册成功后分配的 APP ID
        'APP_SECRET' => '', //应用注册成功后分配的KEY
        'CALLBACK'   => '', //注册应用填写的callback
    ),


    'THINK_SDK_Sina'   => array(
        'APP_KEY'    => '', //应用注册成功后分配的 APP ID
        'APP_SECRET' => '', //应用注册成功后分配的KEY
        'CALLBACK'   => '', //注册应用填写的callback
    )

);