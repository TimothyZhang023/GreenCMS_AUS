<?php
/**
 * Created by Green Studio.
 * File: debug.php
 * User: TianShuo
 * Date: 14-3-11
 * Time: 下午1:25
 */

return array(


    'URL_CASE_INSENSITIVE' => true, //URL大小写不敏感

);