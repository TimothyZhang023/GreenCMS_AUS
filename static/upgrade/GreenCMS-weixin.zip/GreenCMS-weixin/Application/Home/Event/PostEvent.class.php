<?php
/**
 * Created by Green Studio.
 * File: PostEvent.class.php
 * User: TianShuo
 * Date: 14-1-23
 * Time: 下午5:29
 */

namespace Home\Event;

use Home\Controller\HomeBaseController;

class PostEvent extends HomeBaseController
{

}