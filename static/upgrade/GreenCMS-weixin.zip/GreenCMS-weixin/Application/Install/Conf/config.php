<?php
/**
 * Created by Green Studio.
 * File: config.php
 * User: TianShuo
 * Date: 14-2-6
 * Time: 下午3:01
 */
return array(

    'URL_MODEL' => 0,


);