<?php
/**
 * Created by Green Studio.
 * File: MySQLModel.class.php
 * User: TianShuo
 * Date: 14-1-27
 * Time: 下午8:32
 */

namespace Admin\Model;


use Think\Model;

class MySQLModel // extends Model
{

}