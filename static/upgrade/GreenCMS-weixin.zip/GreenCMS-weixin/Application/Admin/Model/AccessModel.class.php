<?php
/**
 * Created by Green Studio.
 * File: AccessModel.class.php
 * User: TianShuo
 * Date: 14-1-26
 * Time: 下午7:26
 */

namespace Admin\Model;

use Think\Model\RelationModel;

class AccessModel extends RelationModel
{

}